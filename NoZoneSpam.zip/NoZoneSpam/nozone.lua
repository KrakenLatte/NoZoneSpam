-- nozone.lua code by Phanx - "addonified" by break19

ZoneTextFrame:UnregisterAllEvents()
ZoneTextFrame:SetScript("OnShow", function() this:Hide() end)
ZoneTextFrame:Hide()
SubZoneTextFrame:UnregisterAllEvents()
SubZoneTextFrame:SetScript("OnShow", function() this:Hide() end)
SubZoneTextFrame:Hide()
